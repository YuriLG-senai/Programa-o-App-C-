﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Pilha
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Stack<int> stack = new Stack<int>();
            //stack.Push(6);
            //stack.Push(100);
            //stack.Push(5);
            //stack.Push(111);
            //stack.Pop();
            //stack.Pop();
            //stack.Pop();
            //stack.Push(900);

            
          
            //    Console.WriteLine("O ultimo valor é: " + stack.Peek());
            
            //Guid guid = Guid.NewGuid();
            //string myGui = guid.ToString();
            //string[] guidBroke = myGui.Split('-');
            

           

            //Stack<string> pilhaGuid = new Stack<string>();

            //foreach (var item in guidBroke)
            //{
            //    pilhaGuid.Push(item);
            //}

            //foreach (var item in pilhaGuid)
            //{

            //    Console.WriteLine(item);

             
            //}
            //Console.WriteLine("Ultimo valor do GUID: " + pilhaGuid.Peek());

            //List<string> myList = new List<string>();

            //for (int i = 0; i < 100000; i++)
            //{
            //    string guid = Guid.NewGuid().ToString();
            //    myList.Add(guid);
            //    Console.WriteLine(guid);
            //}
            //bool duplicado = myList.GroupBy(x => x).Any(g => g.Count() > 0);
            //Console.WriteLine(duplicado);

            int i = 100;
            while (i > 0)
            {
                Thread.Sleep(500);
                i--;
                Console.WriteLine(i.ToString());
            }




        }

        
            
        
    }
}
