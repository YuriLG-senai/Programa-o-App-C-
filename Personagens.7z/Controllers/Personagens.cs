﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Personagens.Models;

namespace Personagens.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Personagens : ControllerBase
    {
        private static List<Personagem> personagens =
            new List<Personagem>
            {
                new Personagem
                {
                    Id = 1,
                    Nome = "Peter",
                    Sobrenome = "Parker",
                    Fantasia = "Homem-Aranha",
                    Local = "NY City"
                },
                new Personagem
                {
                    Id = 2,
                    Nome = "Wade",
                    Sobrenome = "Wilson",
                    Fantasia = "DeadPool",
                    Local = "NY City"
                },
            };
        [HttpGet]
        public ActionResult<List<Personagem>> LerTodosPersonagens()
        {
                return Ok(personagens);
        }
    }
}
