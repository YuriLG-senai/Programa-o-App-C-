﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Personagens.Models;

namespace Personagens.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonagensController : ControllerBase
    {
        private static List<Personagem> personagens = new List<Personagem>
        {
            new Personagem
            {
                Id = 1,
                Nome = "Peter",
                Sobrenome = "Parker",
                Fantasia = "Homem-Aranha",
                Local = "NY City"
            },
            new Personagem
            {
                Id = 2,
                Nome = "Wade",
                Sobrenome = "Wilson",
                Fantasia = "DeadPool",
                Local = "NY City"
            },
        };


        [HttpGet]
        public ActionResult<List<Personagem>> LerTodosPersonagens()
        {
            return Ok(personagens);
        }


        [HttpGet("{id}")]
        public ActionResult<Personagem> LerUnicoPersonagem(int id)
        {
            var unico = personagens.Find(x => x.Id == id);

            if (unico is null)
                return NotFound("Este personagem não se encontra na base de dados");

            return Ok(unico);
        }


        [HttpPost]
        public ActionResult<List<Personagem>> AddPersonagem(Personagem novo)
        {
            if (novo.Id == 0 && personagens.Count > 0)
                novo.Id = personagens[personagens.Count - 1].Id + 1;
            else if (novo.Id == 0)
                novo.Id = 1;

            personagens.Add(novo);
            return Ok(personagens);
        }

        [HttpDelete]
        public ActionResult<List<Personagem>> DelPersonagem(int d)
        {
            var personagem = personagens.FirstOrDefault(p => p.Id == d);

            if (personagem == null)
            {
                return NotFound("Este personagem não existe");
            }
            personagens.Remove(personagem);

            return Ok("Removido com sucesso");

        }

        [HttpGet ("Fantasia/{Fantasia}")]

        public ActionResult<List<Personagem>> LerPorLocal(String Fantasia)
        {


            var personagensPorLocal = personagens.FindAll(x => x.Local == Fantasia);

            if (personagensPorLocal is null)
            {
                return NotFound($"Nenhum personagem encontrado em {Fantasia}");
            }

            return Ok(personagensPorLocal);
        }

        [HttpGet ("Fantasia/{Fantasia}")]

        public ActionResult BuscaFantasia(int id)
        {
            var pesquisa = personagens.Find(x => x.Id == id);

            if (pesquisa is null)
                return NotFound("Essa fantasia não existe.");


                    return Ok(pesquisa.Fantasia);
        }
    }
}
